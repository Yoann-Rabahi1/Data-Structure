#include <stdio.h>
#include "slist.h"

int main(void) {
    // nœud créé à la main
    SNode n1;
    n1.data = 0;
    n1.next = NULL;
    printf("n1.data = %d\n", n1.data);

    // nœud via la fabrique (pointeur)
    SNode *n2 = ds_slist_create_node(20);
    printf("n2->data = %d\n", n2->data);

    // pointeur vers n2
    SNode *pnode = n2;
    printf("pnode->data = %d\n", pnode->data);

    printf("'''''''''''''''''''''''''''''''''''''''''''''''''''''''''");

    // liste 1 : init sur variable
    SList L;
    ds_slist_init(&L);

    // liste 2 : création par valeur
    SList L2 = ds_slist_create();
    (void)L2; // évite un warning si non utilisé

    printf("'''''''''''''''''''''''''''''''''''''''''''''''''''''''''");

    // insertions
    ds_slist_insert_head(&L, 10);
    ds_slist_insert_head(&L, 20);
    ds_slist_insert_head(&L, 30);
    ds_slist_insert_tail(&L, 100);
    ds_slist_insert_tail(&L, 200);

    // affichages
    ds_slist_print(&L);
    ds_slist_print_v1(&L);

    return 0;
}